<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeePayStructure extends Model
{
    use HasFactory;
    protected $table="employee_pay_structures";
}
