<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rate_master extends Model
{
    use HasFactory;
    protected $table="rate_masters";
}
