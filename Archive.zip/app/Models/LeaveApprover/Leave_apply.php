<?php

namespace App\Models\LeaveApprover;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Leave_apply extends Model
{
    use HasFactory;
}
