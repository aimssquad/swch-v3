<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
// use Illuminate\Database\Eloquent\SoftDeletes;

class BillingRemark extends Model
{
    // use SoftDeletes;

   

}
