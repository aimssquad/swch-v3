<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
// use Illuminate\Database\Eloquent\SoftDeletes;

class FormCapstone extends Model
{
    // use SoftDeletes;

    protected $fillable = ['interview_form_id'];

}
