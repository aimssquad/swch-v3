<?php
namespace App\Exceptions;
use Exception;
class AdminException extends Exception
{
   
}
?>