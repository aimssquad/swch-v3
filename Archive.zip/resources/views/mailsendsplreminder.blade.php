<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>SWCH</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
</head>

<body>
	
	<table width="900px" style="margin:auto;font-family: calibri;margin: auto;
    font-family: calibri;
    border: 5px solid #add5f7;
    padding: 10px;">
		<tr>
			<td><h3>Dear Team,</h3></td>
			
		</tr>
		


		<tr>
			<tr><td>
			
<p>
Organisation with name "{{$com_name}}" has been applied for license on {{$application_date}} and decision is still pending. This is {{$days}}-days Reminder. Please take the necessary steps for this company as early as possible.</p>

<p>Yours sincerely</p>
<p>WorkPermitCloud Limited</p>
<p><img width="100px" src="https://workpermitcloud.co.uk/hrms/public/assets/img/logo.png" alt="" /></p>
<p>2nd Floor, 112-116, Whitechapel Road, London, E1 1JE
                        <br>+44-020-8087-2343<br>
                        info@workpermitcloud.co.uk<br>
                        www.workpermitcloudlimited.co.uk<br>
                        VAT Registration# 3843391960</p>
			</td></tr>
		</tr>
	</table>
</body>

</html>