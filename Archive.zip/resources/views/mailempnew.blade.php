<p>Hello ,</p>

 <p>This is  the new employee registration  details: </p>
 
   <p> Employee Code : {{ $emp_code }} </p>
  <p>  Employee Name : {{ $emp_fname}}  {{ $emp_mid_name}} {{ $emp_lname}}.</p>
     <p>  Employee Email : {{ $emp_ps_email}}.</p>
     <p>  Employee Phone Number : {{ $emp_ps_phone}}.</p>
     <p>For further details please check your portal. </p>
  <p>  Thanks</p>