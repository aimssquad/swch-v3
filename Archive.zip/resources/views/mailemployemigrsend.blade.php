<p>Hello <b>{{ $employeedata->emp_fname." ".$employeedata->emp_mname." ".$employeedata->emp_lname }} </b>,</p>



<p>Your visa will expire soon.  </p>
<p>Please  renue your visa.</p>
 
  
  <p>  Thanks & Regards</p>
 
  <p> WORKPERMITCLOUD LIMITED</p>
  



 


