<p>Hello <b>{{ $name }}  </b>,</p>


   <p> Your OTP is  {{ $otp}} for login. </p>


     <p>  Login Link :<a href="{{ $url }}">{{ $url }}</a>.</p>
  <p>  Thanks</p>
