<p>Hello <b>{{ $f_name }}  {{ $l_name }}</b>,</p>

 <p>Thank you for  registering with us.</p>
   <p>Your  User : {{ $email}}.</p>
      <p>Your  Password : {{ $password}}.</p>
      <p>We will verify your document then activate your account and let you know.</p>
  <p>  Thanks</p>