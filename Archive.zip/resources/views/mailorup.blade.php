<p>Hello <b>{{ $f_name }}  {{ $l_name }}</b>,</p>

 <p>This is your login details: </p>
 
   <p> User Name : {{ $email }} </p>
  <p>  Password : {{ $pass}}.</p>
     <p> Now you can create the further settings.</p>
  <p>  Thanks</p>