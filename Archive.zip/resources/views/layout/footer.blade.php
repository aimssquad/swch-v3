<footer class="footer">
    <div class="container-fluid">

        <div class="copyright ml-auto">
            &copy <?php echo date('Y') ?> SWCH | All Right Reserved | Developed by <a href ="#" target="_blank">SWCH</a>
        </div>
    </div>
</footer>
