<p>Hello <b>Superadmin</b>,</p>

 <p>This is new organisation details: </p>
  <p>   Company  Name: {{ $com_name }}</p>
   <p> Name : {{ $f_name }}  {{ $l_name }}</p>
  <p>  Designation : {{ $desig}}.</p>
    <p>  E mail : {{ $email}}.</p>
      <p>  Phone Number : {{ $p_no}}.</p>
  <p>  Thanks</p>