
<p> <b>Dear {{ucfirst($check_user->name)}}</b>,</p>



<p>Your complain is solved.</p>
 
 <p>Here is the details:</p>
 <p>Complain Id: {{$check_complain->id}}</p>
 <p>Project Name: {{$check_complain->p_name}}</p>
 <p>Category : {{$check_complain->cat_name}}  {{$check_complain->others}}</p>
 <p>Company Name : {{$check_com->com_name}}  </p>
  <p>Description: {{$check_complain->descrption}}</p>
  <p>  Best Regards</p>
 
  <p> WorkPermitCloud Limited</p>
  



 


