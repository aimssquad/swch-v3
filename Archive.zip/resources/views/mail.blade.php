<p>Hello <b>{{ $firstname }} {{ $maname }}  {{ $lname }}</b>,</p>

 <p>This is your login details: </p>
  <p>  User Name: {{ $email }}</p>
   <p> Password : {{ $password }}</p>
  <p>  Link : http://workpermitcloud.co.uk/hrms/.</p>
  <p>  Thanks</p>