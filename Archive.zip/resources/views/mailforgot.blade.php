<p>Hello <b>{{ $name }}  </b>,</p>


   <p> Your Password is -  {{ $pass}} for login. </p>


     <p>  Login Link :<a href="{{ $web }}">{{ $web }}</a>.</p>
  <p>  Thanks</p>
