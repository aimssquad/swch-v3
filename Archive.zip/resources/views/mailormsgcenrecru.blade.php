


 {!!html_entity_decode($msg)!!}
 
   <p>  Thanks & Regards</p>
 
  <p>{{$com_name}}</p>