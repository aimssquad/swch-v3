<p>Hello <b>Superadmin</b>,</p>

 <p>This organisation Update their  details: </p>
  <p>   Company  Name: {{ $com_name }}</p>
   <p> Name : {{ $f_name }}  {{ $l_name }}</p>
 
    <p>  E mail : {{ $email}}.</p>
      <p>  Phone Number : {{ $p_no}}.</p>
      <p>Please check it in superadmin portal.</p>
  <p>  Thanks</p>