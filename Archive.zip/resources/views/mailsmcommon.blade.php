<p>Hello <b>{{ $to_name }}</b>,</p>

   <p>   {!! $body_content !!}</p>
  <p>  Thanks</p>
